# app.py
from flask import Flask, render_template, request, jsonify, redirect, url_for
from flask_cors import CORS
import json
from db import Database
from datetime import datetime

app = Flask(__name__)
CORS(app)  # 允许跨域请求

# 初始化数据库
db = Database()

@app.route('/')
def home():
    # 渲染 HTML 页面
    return render_template('index.html')

@app.route('/submit_consultation', methods=['POST'])
def submit_consultation():
    try:
        # 获取表单数据
        if request.is_json:
            data = request.get_json()
        else:
            data = request.form.to_dict()
        
        # 验证必要字段
        if not data.get('name') or not data.get('email') or not data.get('message'):
            return jsonify({
                'success': False,
                'message': 'Name, email, and message are required.'
            }), 400
        
        # 保存到数据库
        consultation_id = db.add_consultation(data)
        
        # 记录日志
        log_submission(data, consultation_id)
        
        return jsonify({
            'success': True,
            'message': 'Thank you for your message! We will contact you within 24 hours.',
            'consultation_id': consultation_id
        }), 200
        
    except Exception as e:
        print(f"Error submitting consultation: {e}")
        return jsonify({
            'success': False,
            'message': 'There was an error submitting your form. Please try again.'
        }), 500

@app.route('/admin/consultations')
def admin_consultations():
    # 简单的管理员页面查看所有咨询
    consultations = db.get_all_consultations()
    return render_template('admin.html', consultations=consultations)

@app.route('/admin/update_status/<int:consultation_id>', methods=['POST'])
def update_status(consultation_id):
    try:
        status = request.form.get('status', 'reviewed')
        db.update_status(consultation_id, status)
        return redirect(url_for('admin_consultations'))
    except Exception as e:
        return str(e), 500

@app.route('/admin/delete/<int:consultation_id>', methods=['POST'])
def delete_consultation(consultation_id):
    try:
        db.delete_consultation(consultation_id)
        return redirect(url_for('admin_consultations'))
    except Exception as e:
        return str(e), 500

def log_submission(data, consultation_id):
    """记录提交日志到文件"""
    log_entry = {
        'timestamp': datetime.now().isoformat(),
        'consultation_id': consultation_id,
        'data': data
    }
    
    try:
        with open('submissions_log.jsonl', 'a') as log_file:
            log_file.write(json.dumps(log_entry) + '\n')
    except Exception as e:
        print(f"Error writing log: {e}")

if __name__ == '__main__':
    # 在 Anaconda 环境中运行时使用以下配置
    app.run(
        host='0.0.0.0',  # 允许外部访问
        port=5000,       # 默认端口
        debug=True,      # 调试模式
        threaded=True    # 支持多线程
    )