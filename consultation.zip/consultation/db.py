# db.py
import sqlite3
from datetime import datetime

class Database:
    def __init__(self, db_name='consultations.db'):
        self.db_name = db_name
        self.create_table()
    
    def get_connection(self):
        return sqlite3.connect(self.db_name)
    
    def create_table(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS consultations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL,
                phone TEXT,
                company TEXT,
                website_url TEXT,
                message TEXT NOT NULL,
                submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                status TEXT DEFAULT 'new'
            )
        ''')
        conn.commit()
        conn.close()
    
    def add_consultation(self, data):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO consultations (name, email, phone, company, website_url, message)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            data['name'],
            data['email'],
            data.get('phone', ''),
            data.get('company', ''),
            data.get('url', ''),
            data['message']
        ))
        
        conn.commit()
        consultation_id = cursor.lastrowid
        conn.close()
        
        return consultation_id
    
    def get_all_consultations(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM consultations ORDER BY submitted_at DESC')
        consultations = cursor.fetchall()
        
        conn.close()
        return consultations
    
    def get_consultation_by_id(self, consultation_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM consultations WHERE id = ?', (consultation_id,))
        consultation = cursor.fetchone()
        
        conn.close()
        return consultation
    
    def update_status(self, consultation_id, status):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            UPDATE consultations 
            SET status = ? 
            WHERE id = ?
        ''', (status, consultation_id))
        
        conn.commit()
        conn.close()
        return True
    
    def delete_consultation(self, consultation_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('DELETE FROM consultations WHERE id = ?', (consultation_id,))
        
        conn.commit()
        conn.close()
        return True